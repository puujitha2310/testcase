import React, { Component } from "react";
import  QuestionnaireComp from './components/Questionnaire'

class App extends Component {
  
  render() {
    return <QuestionnaireComp />
  }
}

export default App;
